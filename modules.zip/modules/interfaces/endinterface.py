import sys 
import pygame as pg

def endInterface(screen, image_path, score, font_path, font_colors, screensize):
    end_image = pg.image.load(image_path)
    font = pg.font.Font(font_path, 50)

    score_text = font.render('Your score: ' + str(score), True, font_colors[0])

    score_rect = score_text.get_rect()
    score_rect.left = ((screensize[0]- score_rect.width)/2)
    score_rect.top = 215
    while True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
                return True
        screen.blit(end_image, (0, 0))
        screen.blit(score_text, score_rect)
        pg.display.update() 
