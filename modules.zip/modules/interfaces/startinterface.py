import pygame as pg
import sys 
def startInterface(screen, begin_image_paths):
    begin_images = [
        pg.image.load(begin_image_paths[0]),
        pg.image.load(begin_image_paths[1])]
    begin_image = begin_images[0]
    while True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            elif event.type == pg.MOUSEMOTION:
                mouse_pos = pg.mouse.get_pos()
                if mouse_pos[0] in list(range(366, 626)) and mouse_pos[1] in list(range(70, 140)):
                    begin_image = begin_images[1]
                else:
                    begin_image = begin_images[0]
            elif event.type == pg.MOUSEBUTTONDOWN:
                mouse_pos = pg.mouse.get_pos()
                if event.button == 1 and mouse_pos[0] in list(range(366, 626)) and mouse_pos[1] in list(range(70, 140)):
                    return True
        screen.blit(begin_image, (0, 0))
        pg.display.update()