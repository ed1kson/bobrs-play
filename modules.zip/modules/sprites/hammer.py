import pygame as pg

class Hammer(pg.sprite.Sprite):
    def __init__(self, image_paths, pos, **kwargs):
        super().__init__()
        self.images = [pg.image.load(image_paths[0]), pg.image.load(image_paths[1])]
        self.image = self.images[0]
        self.rect = self.image.get_rect()
        self.mask = pg.mask.from_surface(self.images[1])
        self.rect.left, self.rect.top = pos
        self.hammering_count = 0
        self.hammer_last_time = 4
        self.is_hammering = False
    def SetPosition(self, pos):
        self.rect.centerx, self.rect.centery = pos
    def setHammering(self):
        self.is_hammering = True
    def draw(self, screen):
        if self.is_hammering == True:
            self.image = self.images[1]
            self.hammering_count += 1
            if self.hammering_count == self.hammer_last_time:
                self.is_hammering = False
                self.hammering_count = 0
        else:
            self.image = self.images[0]
        screen.blit(self.image, self.rect)